import React from 'react';
import { render, screen ,cleanup } from '@testing-library/react';
import TestElements from './TestElements'

afterEach(cleanup);

  it('should equal to 0', () => {
   render(<TestElements />); 
    expect(screen.getByTestId('counter')).toHaveTextContent(0)
   });
   it('should be enabled', () => {
     render(<TestElements />);
    expect(screen.getByTestId('button-up')).not.toHaveAttribute('disabled')
  });

  it('should be disabled', () => {
    render(<TestElements />); 
    expect(screen.getByTestId('button-down')).toBeDisabled()
  });