import { useSelector } from "react-redux";
import React from "react";
const DisplayCount = () => {
  const response = useSelector((state) => {
    const result = { count: state.count };
    return result;
  });

  return (
    <div>
      <h1>Displays Count component </h1>
      Count is {response.count}
    </div>
  );
};
export default DisplayCount;
