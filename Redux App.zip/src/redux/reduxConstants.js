
const reduxConstants={
 
    increment: "increment",

    decrement: "decrement",

    reset: "reset"


}

export default reduxConstants;